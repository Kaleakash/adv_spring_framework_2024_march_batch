package com.example.springbootreativerestapiconsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootReativeRestApiConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootReativeRestApiConsumerApplication.class, args);
	}

}
